import {useEffect, useState} from 'react';
import {Trash2, ShieldAlert, Eye, CheckCircle2, Lock} from 'lucide-react';
import {apiFetch} from '../api/client';
import {DataTable, Kpi, Panel} from './ui';

// Removing trial data before real accounting begins.
// The destructive path is deliberately slow: preview -> dry run -> type the
// company name -> execute. Configuration and the chart of accounts are kept.

async function json(url:string,init?:RequestInit){
  const r=await apiFetch(url,init); const x=await r.json().catch(()=>({}));
  if(!r.ok){
    const d=x.detail;
    const msg = typeof d==='string' ? d
      : (d && (d.message_ar||d.message_en)) ? (d.message_ar||d.message_en)
      : JSON.stringify(d||x);
    throw new Error(msg);
  }
  return x;
}
const field={display:'block',width:'100%',marginTop:5,padding:9,border:'1px solid var(--border)',borderRadius:9} as const;
const btn={padding:'9px 16px',borderRadius:9,border:'none',background:'var(--accent, #1e40af)',color:'#fff',cursor:'pointer',fontWeight:600} as const;
const danger={...btn,background:'#b91c1c'} as const;

export function DataResetPage({ar,companyId}:{ar:boolean;companyId:number}){
  const [preview,setPreview]=useState<any>(null);
  const [confirmation,setConfirmation]=useState('');
  const [msg,setMsg]=useState(''); const [err,setErr]=useState(false); const [busy,setBusy]=useState(false);
  const [dryDone,setDryDone]=useState(false);

  const load=async()=>{
    setMsg('');setErr(false);
    try{
      const r=await json(`/api/v1/data-reset/preview?company_id=${companyId}`);
      setPreview(r); setDryDone(false); setConfirmation('');
    }catch(e:any){setMsg(String(e.message||e));setErr(true);}
  };
  useEffect(()=>{load()},[companyId]);

  const run=async(dry:boolean)=>{
    setBusy(true);setMsg('');setErr(false);
    try{
      const r=await json('/api/v1/data-reset/execute',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({company_id:companyId,confirmation:confirmation.trim(),dry_run:dry})});
      setMsg(ar?r.message_ar:r.message_en); setErr(false);
      if(dry) setDryDone(true); else { setDryDone(false); await load(); }
    }catch(e:any){setMsg(String(e.message||e));setErr(true);}finally{setBusy(false);}
  };

  const phrase = preview?.confirmation_phrase || '';
  const matches = confirmation.trim() === phrase.trim() && phrase.length>0;
  const enabled = preview?.enabled;
  const rows = Object.entries(preview?.tables||{}) as [string,number][];

  return <>
    <div className="kpis">
      <Kpi title={ar?'صفوف ستُحذف':'Rows to remove'} value={String(preview?.total_rows ?? '—')} trend="" good={(preview?.total_rows||0)===0} icon={<Trash2 size={22}/>} tone="amber"/>
      <Kpi title={ar?'جداول متأثرة':'Tables'} value={String(rows.length)} trend="" good icon={<Eye size={22}/>} tone="blue"/>
      <Kpi title={ar?'جداول محفوظة':'Preserved'} value={String((preview?.preserved||[]).length)} trend={ar?'لا تُمس':'untouched'} good icon={<CheckCircle2 size={22}/>} tone="green"/>
      <Kpi title={ar?'الأداة':'Reset tool'} value={enabled?(ar?'مفعّلة':'Enabled'):(ar?'مقفلة':'Locked')} trend="ALLOW_DATA_RESET" good={!enabled} icon={<Lock size={22}/>} tone="violet"/>
    </div>

    {msg&&<div style={{padding:11,margin:'12px 0',borderRadius:9,fontSize:14,lineHeight:1.8,
      background:err?'#fee2e2':'#dcfce7',color:err?'#991b1b':'#166534'}}>{msg}</div>}

    <Panel title={ar?'ما الذي سيُحذف وما الذي سيبقى':'What is removed and what is kept'} icon={<ShieldAlert size={18}/>}>
      <div style={{padding:'10px 14px',display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:14}}>
        <div style={{padding:13,borderRadius:10,background:'#fef2f2',color:'#7f1d1d',lineHeight:1.9,fontSize:13}}>
          <b>{ar?'يُحذف — بيانات الحركة':'Removed — movement data'}</b><br/>
          {ar
            ? 'القيود · فواتير البيع والشراء · سندات القبض والصرف · حركات المخزون · طلبات الشراء · أوامر الإنتاج · فحوصات الجودة · أوامر البيع في نقاط البيع · المشروعات والمستخلصات · العمولات · المرفقات · الرواتب والحضور · الإهلاك · الأصول الثابتة · الإيجارات · المقدمة والاستحقاقات · الصيانة والأسطول والقانونية · التذاكر والحملات · الإقرارات الضريبية'
            : 'Journals, invoices, receipts, payments, stock moves, purchase orders, production orders, inspections, POS orders, projects, commissions, attachments, payroll, depreciation, fixed assets, leases, prepaids, accruals, maintenance, fleet, legal, tickets, campaigns, tax returns'}
        </div>
        <div style={{padding:13,borderRadius:10,background:'#f0fdf4',color:'#14532d',lineHeight:1.9,fontSize:13}}>
          <b>{ar?'يبقى — إعداداتك':'Kept — your configuration'}</b><br/>
          {ar
            ? 'الشركات والفروع ومراكز التكلفة · شجرة الحسابات كاملة · المستخدمون والأدوار والصلاحيات · الفترات المالية · المستودعات والأصناف · العملاء والموردون · الموظفون · الحسابات البنكية · فئات الأصول · الرموز الضريبية · قوائم المواد · سجل التدقيق'
            : 'Companies, branches, cost centres, the full chart of accounts, users, roles, permissions, fiscal periods, warehouses, items, parties, employees, bank accounts, asset categories, tax codes, BOMs, the audit log'}
        </div>
      </div>
    </Panel>

    {!enabled&&<Panel title={ar?'الأداة مقفلة':'The tool is locked'} icon={<Lock size={18}/>}>
      <div style={{padding:14,fontSize:14,lineHeight:2}}>
        {ar
          ? <>الحذف معطّل افتراضيًا حمايةً لبياناتك. لتفعيله مؤقتًا، أضف في إعدادات الاستضافة المتغيّر <code>ALLOW_DATA_RESET</code> بقيمة <code>true</code>، ثم <b>أعده إلى <code>false</code> بعد الانتهاء</b>.</>
          : <>Reset is disabled by default. Set <code>ALLOW_DATA_RESET=true</code> in the environment to enable it, then set it back to <code>false</code> when you are done.</>}
      </div>
    </Panel>}

    <Panel title={ar?'الصفوف التي ستُحذف':'Rows that will be removed'} icon={<Eye size={18}/>}>
      {rows.length===0
        ? <div style={{padding:16,fontSize:14,opacity:0.8}}>{ar?'لا توجد بيانات حركة في هذه الشركة — النظام نظيف بالفعل.':'No movement data in this company — already clean.'}</div>
        : <DataTable headers={[ar?'الجدول':'Table',ar?'عدد الصفوف':'Rows']} rows={rows.map(([t,n])=>[t,String(n)])}/>}
    </Panel>

    {enabled&&rows.length>0&&<Panel title={ar?'التنفيذ':'Execute'} icon={<Trash2 size={18}/>}>
      <div style={{padding:'12px 14px',fontSize:14,lineHeight:2}}>
        <b>{ar?'الخطوة ١ — جرّب بلا تنفيذ:':'Step 1 — dry run:'}</b><br/>
        {ar?'يعرض ما سيحدث دون أن يحذف شيئًا.':'Shows the impact without deleting anything.'}
      </div>
      <div style={{padding:'0 14px 12px'}}>
        <button style={{...btn,opacity:busy?0.6:1}} disabled={busy||!matches} onClick={()=>run(true)}>
          {ar?'تجربة بلا تنفيذ':'Dry run'}
        </button>
      </div>

      <div style={{padding:'6px 14px',fontSize:14,lineHeight:2,borderTop:'1px solid var(--border)'}}>
        <b>{ar?'الخطوة ٢ — أكّد باسم الشركة:':'Step 2 — confirm with the company name:'}</b><br/>
        {ar?'اكتب اسم الشركة بالضبط كما هو مكتوب أدناه.':'Type the company name exactly as shown.'}
        <div style={{marginTop:8,padding:'8px 12px',borderRadius:8,background:'var(--panel-2, #f1f5f9)',fontWeight:700,display:'inline-block'}}>{phrase}</div>
      </div>
      <div style={{padding:'0 14px 12px',maxWidth:420}}>
        <input style={field} value={confirmation} onChange={e=>setConfirmation(e.target.value)}
          placeholder={ar?'اكتب اسم الشركة هنا':'Type the company name'}/>
        {confirmation&&!matches&&<small style={{color:'#b91c1c'}}>{ar?'غير مطابق':'Does not match'}</small>}
        {matches&&<small style={{color:'#166534'}}>{ar?'✓ مطابق':'✓ matches'}</small>}
      </div>

      <div style={{padding:'6px 14px 16px',borderTop:'1px solid var(--border)'}}>
        <div style={{fontSize:14,lineHeight:2,marginBottom:10}}>
          <b>{ar?'الخطوة ٣ — الحذف النهائي:':'Step 3 — delete for real:'}</b><br/>
          <span style={{color:'#b91c1c'}}>{ar?'لا رجعة في هذه الخطوة. تأكد من وجود نسخة احتياطية.':'This cannot be undone. Make sure you have a backup.'}</span>
        </div>
        <button style={{...danger,opacity:(busy||!matches||!dryDone)?0.5:1}}
          disabled={busy||!matches||!dryDone} onClick={()=>run(false)}>
          {ar?'حذف البيانات التجريبية نهائيًا':'Delete trial data permanently'}
        </button>
        {!dryDone&&<div style={{marginTop:8,fontSize:13,opacity:0.75}}>
          {ar?'شغّل التجربة أولًا لتفعيل هذا الزر.':'Run the dry run first to enable this button.'}
        </div>}
      </div>
    </Panel>}
  </>;
}
