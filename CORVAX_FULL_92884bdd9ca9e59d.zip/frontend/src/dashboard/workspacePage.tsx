import {useEffect, useMemo, useState} from 'react';
import {Download, RefreshCw, Search, ShieldCheck, Workflow} from 'lucide-react';
import {DataTable, Kpi, Panel, authHeaders, money} from './ui';

type QueueItem={module:string;item_type:string;id:number;number:string;status:string;title:string;amount:number;created_at?:string};

export function WorkspacePage({ar,companyId}:{ar:boolean;companyId:number}){
  const [items,setItems]=useState<QueueItem[]>([]);const [counts,setCounts]=useState<Record<string,number>>({});
  // FIX: the header search bar navigated to /workbench?q=... but this page never
  // read the parameter, so the typed text was silently dropped and the page
  // opened empty. It now seeds the box from the URL and searches immediately.
  const initialQuery=(()=>{try{return new URLSearchParams(window.location.search).get('q')||''}catch{return ''}})();
  const [query,setQuery]=useState(initialQuery);const [results,setResults]=useState<QueueItem[]>([]);const [busy,setBusy]=useState(false);const [message,setMessage]=useState('');
  const load=async()=>{setBusy(true);try{const r=await fetch(`/api/v1/workspace/work-queue?company_id=${companyId}&limit=200`,{headers:authHeaders()});const data=await r.json();if(!r.ok)throw new Error(data.detail||'Work queue failed');setItems(data.items||[]);setCounts(data.by_module||{});setMessage('')}catch(e:any){setMessage(e.message)}finally{setBusy(false)}};
  useEffect(()=>{load()},[companyId]);
  // Search straight away when the user arrived from the header search bar.
  useEffect(()=>{if(initialQuery.trim().length>=2){search()}},[]);  // eslint-disable-line react-hooks/exhaustive-deps
  async function search(){if(query.trim().length<2){setResults([]);return}setBusy(true);try{const r=await fetch(`/api/v1/workspace/search?company_id=${companyId}&q=${encodeURIComponent(query.trim())}`,{headers:authHeaders()});const data=await r.json();if(!r.ok)throw new Error(data.detail||'Search failed');setResults(data.results||[]);setMessage('')}catch(e:any){setMessage(e.message)}finally{setBusy(false)}}
  const totalAmount=useMemo(()=>items.reduce((n,x)=>n+Number(x.amount||0),0),[items]);
  const shown=query.trim().length>=2?results:items;
  async function exportCsv(){const r=await fetch(`/api/v1/workspace/work-queue.csv?company_id=${companyId}`,{headers:authHeaders()});if(!r.ok){setMessage(ar?'تعذر التصدير':'Export failed');return}const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`corvax-work-queue-${companyId}.csv`;a.click();URL.revokeObjectURL(url)}
  return <>
    <div className="kpis rich"><Kpi title={ar?'إجمالي المهام المفتوحة':'Open work items'} value={String(items.length)} trend={ar?'من قاعدة البيانات مباشرة':'Live database'} good={items.length===0}/><Kpi title={ar?'النادي':'Gym'} value={String(counts.GYM||0)} trend={ar?'عضويات ومرافق':'Memberships & facilities'} good={(counts.GYM||0)===0}/><Kpi title={ar?'المطاعم ونقاط البيع':'Restaurant & POS'} value={String(counts.POS||0)} trend={ar?'إلغاءات وتسويات':'Controls & settlements'} good={(counts.POS||0)===0}/><Kpi title={ar?'الرواتب':'Payroll'} value={String(counts.HR||0)} trend={money.format(totalAmount)} good={(counts.HR||0)===0}/></div>
    <div className="journal-footer"><span>{message||(ar?'مركز موحد للبحث والمهام والاعتمادات مع منع الاعتماد الذاتي.':'Unified search, work queue and approvals with maker-checker control.')}</span><div style={{display:'flex',gap:8}}><button disabled={busy} onClick={load}><RefreshCw size={15}/>{ar?'تحديث':'Refresh'}</button><button onClick={exportCsv}><Download size={15}/>{ar?'تصدير CSV':'Export CSV'}</button></div></div>
    <Panel title={ar?'البحث الشامل في النظام':'Global system search'} icon={<Search size={18}/> }><div className="workbench-search"><input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&search()} placeholder={ar?'ابحث برقم المستند أو اسم العميل أو الحالة...':'Search document number, customer or status...'}/><button disabled={busy||query.trim().length<2} onClick={search}>{ar?'بحث':'Search'}</button>{query&&<button className="secondary" onClick={()=>{setQuery('');setResults([])}}>{ar?'مسح':'Clear'}</button>}</div></Panel>
    <div className="three-columns"><div className="mini-status"><Workflow size={20}/><div><span>{ar?'قائمة موحدة':'Unified queue'}</span><strong>{items.length}</strong><small>{ar?'مرتبة حسب الأحدث':'Newest first'}</small></div></div><div className="mini-status"><ShieldCheck size={20}/><div><span>{ar?'الرقابة':'Control'}</span><strong>Maker–Checker</strong><small>{ar?'منع الاعتماد الذاتي':'Self-approval blocked'}</small></div></div><div className="mini-status"><Search size={20}/><div><span>{ar?'نتائج البحث':'Search results'}</span><strong>{query?results.length:items.length}</strong><small>{ar?'عبر النادي وPOS والرواتب':'Across gym, POS and payroll'}</small></div></div></div>
    <Panel title={query?(ar?'نتائج البحث':'Search results'):(ar?'قائمة العمل والاعتمادات':'Work queue and approvals')} icon={<Workflow size={18}/> }><DataTable headers={[ar?'الوحدة':'Module',ar?'النوع':'Type',ar?'الرقم':'Number',ar?'الوصف':'Description',ar?'القيمة':'Amount',ar?'الحالة':'Status',ar?'التاريخ':'Created']} rows={shown.map(r=>[r.module,r.item_type,r.number,r.title,money.format(Number(r.amount||0)),r.status,r.created_at?new Date(r.created_at).toLocaleString(ar?'ar-SA':'en-GB'):'—'])}/></Panel>
  </>;
}
